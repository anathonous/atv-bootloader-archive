#!/bin/bash
# Version 1.0 (Febuary 24, 2008)
#
# This script unpacks and install the i386 darwin cross-compiler tools
# into /opt. It must go into /opt as there are build dependencies and
# must be run via sudo.
#
# Darwin-cross tools is required for bulding atv-bootloader. The bootloader
# is a darwin mach-o executable and must be compiled using these tools.
#
# Building darwin cross compiler tools is tricky and it's easer to grab them
# pre built. See the following sites for reference or
# google fop "darwin-cross"
#
# http://www.mythic-beasts.com/resources/appletv/mb_boot_tv/
# http://ranger.befunk.com/fink/darwin-cross/
#
#
echo "Extracting darwin-cross tools"
sudo tar -xzf darwin-cross.tar.gz
echo "Moving darwin-cross to /opt"
sudo mv -f darwin-cross /opt/
#
# Done
